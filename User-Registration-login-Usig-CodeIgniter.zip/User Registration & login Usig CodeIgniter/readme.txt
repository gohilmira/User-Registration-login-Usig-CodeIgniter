How to run the User registration and login using CodeIgniter

1.Download the zip file

2.Extract the file and copy registration-ci folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name cidb

6.Import cidb file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/registration-ci



User Credential
Username: ak@gmail.com
Password: Test@123
or Register a new user


